<?php
/**
 * BXH LVGames back compat functionality
 *
 * Prevents BXH LVGames from running on WordPress versions prior to 4.1,
 * since this theme is not meant to be backward compatible beyond that and
 * relies on many newer functions and markup changes introduced in 4.1.
 *
 * @package WordPress
 * @subpackage BXH_LVGames
 * @since BXH LVGames 1.0
 */

/**
 * Prevent switching to BXH LVGames on old versions of WordPress.
 *
 * Switches to the default theme.
 *
 * @since BXH LVGames 1.0
 */
function bxhlvgames_switch_theme() {
	switch_theme( WP_DEFAULT_THEME, WP_DEFAULT_THEME );
	unset( $_GET['activated'] );
	add_action( 'admin_notices', 'bxhlvgames_upgrade_notice' );
}
add_action( 'after_switch_theme', 'bxhlvgames_switch_theme' );

/**
 * Add message for unsuccessful theme switch.
 *
 * Prints an update nag after an unsuccessful attempt to switch to
 * BXH LVGames on WordPress versions prior to 4.1.
 *
 * @since BXH LVGames 1.0
 */
function bxhlvgames_upgrade_notice() {
	$message = sprintf( __( 'BXH LVGames requires at least WordPress version 4.1. You are running version %s. Please upgrade and try again.', 'bxhlvgames' ), $GLOBALS['wp_version'] );
	printf( '<div class="error"><p>%s</p></div>', $message );
}

/**
 * Prevent the Customizer from being loaded on WordPress versions prior to 4.1.
 *
 * @since BXH LVGames 1.0
 */
function bxhlvgames_customize() {
	wp_die( sprintf( __( 'BXH LVGames requires at least WordPress version 4.1. You are running version %s. Please upgrade and try again.', 'bxhlvgames' ), $GLOBALS['wp_version'] ), '', array(
		'back_link' => true,
	) );
}
add_action( 'load-customize.php', 'bxhlvgames_customize' );

/**
 * Prevent the Theme Preview from being loaded on WordPress versions prior to 4.1.
 *
 * @since BXH LVGames 1.0
 */
function bxhlvgames_preview() {
	if ( isset( $_GET['preview'] ) ) {
		wp_die( sprintf( __( 'BXH LVGames requires at least WordPress version 4.1. You are running version %s. Please upgrade and try again.', 'bxhlvgames' ), $GLOBALS['wp_version'] ) );
	}
}
add_action( 'template_redirect', 'bxhlvgames_preview' );
