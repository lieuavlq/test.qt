<?php
	$zkname_fm = esc_html($_GET['zkname_fm']);
	$zkphone_fm = esc_html($_GET['zkphone_fm']);
	$zkpoint_fm = esc_html($_GET['zkpoint_fm']);
	$zkrank_fm = esc_html($_GET['zkrank_fm']);
	$zknumber_fm = esc_html($_GET['zknumber_fm']);
	$zkdate_fm = esc_html($_GET['zkdate_fm']);

	if($zkname_fm) {
    echo $zkname_fm;
	}
?>